<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-10 09:50:22 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 10:27:17 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 10:28:40 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 10:29:31 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 10:32:28 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 10:37:17 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 10:38:08 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 10:52:40 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 10:59:41 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:03:02 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:11:39 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:15:10 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:19:44 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:22:32 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:23:27 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:23:53 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:24:40 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 11:25:50 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 12:27:25 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 12:29:45 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 12:34:42 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 12:39:02 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 12:50:14 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-10 13:29:06 --> 404 Page Not Found: Css/bootstrap.min.css.map
