<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-15 04:01:07 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 04:01:22 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 04:01:27 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 04:03:08 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 04:03:22 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 04:07:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Companyview.php:15) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-15 04:07:24 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/controllers/Companyview.php 15
ERROR - 2016-12-15 04:07:25 --> 404 Page Not Found: Companyview/new-company
ERROR - 2016-12-15 06:15:22 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:17:51 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:17:56 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:18:18 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:18:18 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:18:19 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:18:20 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:18:20 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:18:21 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:28:39 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:29:29 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:29:34 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:30:00 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:30:23 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:31:58 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:32:27 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:43:18 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:47:49 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/views/userfiles.php 5
ERROR - 2016-12-15 06:47:49 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/models/User_model.php 40
ERROR - 2016-12-15 06:47:50 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:48:05 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/views/userfolders.php 5
ERROR - 2016-12-15 06:49:51 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:50:11 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 06:51:07 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 11:24:28 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 12:34:32 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 12:36:03 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 12:37:24 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/models/User_model.php 40
ERROR - 2016-12-15 12:39:25 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 12:42:42 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 12:45:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 529
ERROR - 2016-12-15 12:45:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 543
ERROR - 2016-12-15 12:45:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 552
ERROR - 2016-12-15 12:45:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 582
ERROR - 2016-12-15 12:45:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 596
ERROR - 2016-12-15 12:45:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 605
ERROR - 2016-12-15 12:46:37 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 12:50:03 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 12:52:19 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-15 12:54:13 --> 404 Page Not Found: Css/bootstrap.min.css.map
