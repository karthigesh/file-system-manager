<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-12 04:47:33 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 05:54:30 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 05:54:50 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 05:54:53 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 05:57:05 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 06:01:27 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 06:01:40 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 07:15:20 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 09:35:39 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 09:36:19 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 10:26:25 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 10:29:47 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 12:51:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 559
ERROR - 2016-12-12 12:51:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 569
ERROR - 2016-12-12 12:51:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 575
ERROR - 2016-12-12 12:51:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 604
ERROR - 2016-12-12 12:51:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 614
ERROR - 2016-12-12 12:51:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 620
ERROR - 2016-12-12 12:54:42 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 559
ERROR - 2016-12-12 12:54:42 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 569
ERROR - 2016-12-12 12:54:42 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 575
ERROR - 2016-12-12 12:54:42 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 604
ERROR - 2016-12-12 12:54:42 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 614
ERROR - 2016-12-12 12:54:42 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 620
ERROR - 2016-12-12 12:54:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 559
ERROR - 2016-12-12 12:54:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 569
ERROR - 2016-12-12 12:54:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 575
ERROR - 2016-12-12 12:54:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 604
ERROR - 2016-12-12 12:54:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 614
ERROR - 2016-12-12 12:54:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 620
ERROR - 2016-12-12 12:54:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 559
ERROR - 2016-12-12 12:54:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 569
ERROR - 2016-12-12 12:54:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 575
ERROR - 2016-12-12 12:54:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 604
ERROR - 2016-12-12 12:54:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 614
ERROR - 2016-12-12 12:54:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 620
ERROR - 2016-12-12 12:54:55 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 559
ERROR - 2016-12-12 12:54:55 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 569
ERROR - 2016-12-12 12:54:55 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 575
ERROR - 2016-12-12 12:54:55 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 604
ERROR - 2016-12-12 12:54:55 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 614
ERROR - 2016-12-12 12:54:55 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 620
ERROR - 2016-12-12 12:54:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 559
ERROR - 2016-12-12 12:54:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 569
ERROR - 2016-12-12 12:54:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 575
ERROR - 2016-12-12 12:54:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 604
ERROR - 2016-12-12 12:54:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 614
ERROR - 2016-12-12 12:54:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 620
ERROR - 2016-12-12 12:55:03 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 559
ERROR - 2016-12-12 12:55:03 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 569
ERROR - 2016-12-12 12:55:03 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 575
ERROR - 2016-12-12 12:55:03 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 604
ERROR - 2016-12-12 12:55:03 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 614
ERROR - 2016-12-12 12:55:03 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 620
ERROR - 2016-12-12 13:35:38 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 13:36:41 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-12 13:36:49 --> 404 Page Not Found: Css/bootstrap.min.css.map
