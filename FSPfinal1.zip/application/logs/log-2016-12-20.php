<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-20 06:17:46 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/views/search.php 125
ERROR - 2016-12-20 06:17:55 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/views/search.php 125
ERROR - 2016-12-20 06:18:06 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/views/search.php 125
ERROR - 2016-12-20 06:18:51 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/views/search.php 125
ERROR - 2016-12-20 06:18:57 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/views/search.php 125
ERROR - 2016-12-20 06:19:20 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/views/search.php 125
ERROR - 2016-12-20 06:19:35 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/views/search.php 125
ERROR - 2016-12-20 06:19:45 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/views/search.php 125
