<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-13 04:12:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 559
ERROR - 2016-12-13 04:12:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 569
ERROR - 2016-12-13 04:12:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 575
ERROR - 2016-12-13 04:12:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 604
ERROR - 2016-12-13 04:12:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 614
ERROR - 2016-12-13 04:12:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/user_search.php 620
ERROR - 2016-12-13 09:40:35 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 09:44:55 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 11:38:00 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 11:40:01 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 11:54:35 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 11:57:29 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 11:57:50 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 11:59:12 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:32:56 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:34:47 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:35:48 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:38:28 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:41:52 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:42:50 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:50:48 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:51:02 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:53:46 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 12:53:52 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 14:29:10 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-13 14:31:47 --> 404 Page Not Found: Css/bootstrap.min.css.map
