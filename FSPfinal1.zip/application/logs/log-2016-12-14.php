<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-14 00:57:20 --> 404 Page Not Found: Ib/html5shiv
ERROR - 2016-12-14 00:57:20 --> 404 Page Not Found: Lib/respond
ERROR - 2016-12-14 04:08:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folderfiles.php 605
ERROR - 2016-12-14 04:08:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folderfiles.php 619
ERROR - 2016-12-14 04:08:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folderfiles.php 628
ERROR - 2016-12-14 04:08:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folderfiles.php 658
ERROR - 2016-12-14 04:08:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folderfiles.php 672
ERROR - 2016-12-14 04:08:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folderfiles.php 681
ERROR - 2016-12-14 04:32:30 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 04:37:52 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 04:42:42 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 04:50:19 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 05:04:24 --> 404 Page Not Found: Company/index
ERROR - 2016-12-14 05:04:54 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/models/User_model.php 40
ERROR - 2016-12-14 05:05:16 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/models/User_model.php 40
ERROR - 2016-12-14 05:07:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:23 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:26 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:34 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:35 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:35 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:35 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:35 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:35 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:36 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:36 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:36 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:36 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:36 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:37 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:37 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:37 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:37 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:39 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:39 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:39 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:40 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:40 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:40 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:41 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:41 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:41 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:41 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:41 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:42 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:42 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:42 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:46 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:46 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:47 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:47 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:47 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:49 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:51 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:51 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:51 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:51 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:51 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:52 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:52 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:52 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:52 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:52 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:55 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:55 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:55 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:55 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:56 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:56 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:56 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:56 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:07:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:07:56 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:50 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:50 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:50 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:50 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:51 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:51 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:52 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:52 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:52 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:53 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:08:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:08:54 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:09 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:10 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:10 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:10 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:10 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:10 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:10 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:11 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:11 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:11 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:11 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:11 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:12 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:12 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:12 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:12 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:12 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:13 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:13 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:13 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:13 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:14 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:11:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:11:14 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:26:59 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:27:09 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 05:28:01 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:28:03 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:28:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:28:09 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:28:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:28:10 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:28:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:28:10 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:28:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:28:11 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:28:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:28:11 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:28:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:28:11 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:28:16 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:28:23 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:28:33 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:28:45 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:28:48 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:28:55 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:28:57 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:29:01 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:29:08 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:29:12 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:29:19 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:29:58 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:30:01 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:30:06 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:30:11 --> 404 Page Not Found: Images/avatars
ERROR - 2016-12-14 05:30:23 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 05:31:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:31:18 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:31:20 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 05:31:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:31:28 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:31:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:31:29 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:31:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:31:29 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:31:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:31:29 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:31:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:31:29 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:32:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:32:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:32:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:32:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:32:12 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:32:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:26 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:27 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:27 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:27 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:27 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:31 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:31 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:31 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:32 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:32:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:32:32 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:44:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:44:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:44:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:44:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:44:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:44:59 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:14 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:20 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:20 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:20 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:20 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:20 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:20 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:21 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:21 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:21 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:21 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:21 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:21 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:22 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:22 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:22 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:22 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:22 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:22 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:45:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:45:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:45:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:45:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:45:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:45:43 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:45:49 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:45:57 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:47:53 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:47:53 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:47:53 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:47:53 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:47:53 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:47:53 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:47:57 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:47:57 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:47:57 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:47:57 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:47:57 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:47:57 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:10 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:10 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:10 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:10 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:10 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:10 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:13 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:13 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:13 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:13 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:13 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:13 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:16 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:48:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:29 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:48:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:48 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:48 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:48 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:48 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:48 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:48 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:52 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:48:52 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:48:52 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:48:52 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:48:52 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:48:52 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:48:57 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:49:09 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:49:09 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:49:09 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:49:09 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:49:09 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:49:09 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:49:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:49:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:49:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:49:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:49:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:49:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:50:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:50:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:50:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:50:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:50:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:50:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:50:17 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:50:17 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:50:17 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:50:17 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:50:17 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:50:17 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:50:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:50:46 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:52:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Company.php:140) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 05:52:59 --> Severity: Error --> Call to undefined method Company_model::companyauth() /home/power/public_html/B202/application/controllers/Company.php 140
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:26 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:27 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:32 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:32 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:32 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:32 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:32 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:32 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:36 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:36 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:36 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:36 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:36 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:36 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:38 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:38 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:38 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:38 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:38 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:38 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:39 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:39 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:39 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:39 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:39 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:39 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:40 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:53:46 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:53:58 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:53:58 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:53:58 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:53:58 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:53:58 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:53:58 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:54:00 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 05:54:08 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:54:34 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 05:55:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:55:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:55:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:55:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:55:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:55:44 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:55:47 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:55:47 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:55:47 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:55:47 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:55:47 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:55:47 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:55:52 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:56:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:56:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:56:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:56:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:56:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:56:01 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:56:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:56:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:56:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:56:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:56:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:56:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:56:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:56:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:56:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:56:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:56:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:56:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:56:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:56:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:56:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:56:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:56:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:56:18 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:56:26 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:56:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:56:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:56:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:56:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:56:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:56:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:58:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:58:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:58:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:58:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:58:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:58:23 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:58:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:58:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:58:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:58:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:58:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:58:25 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:58:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:58:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:58:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:58:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:58:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:58:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:58:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:58:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:58:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:58:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:58:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:58:34 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:58:37 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:59:19 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:59:19 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:59:19 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:59:19 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:59:19 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:59:19 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:59:24 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:59:24 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:59:24 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:59:24 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:59:24 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:59:24 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:59:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:59:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:59:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:59:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:59:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:59:33 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:59:41 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 05:59:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:59:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:59:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:59:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:59:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:59:46 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:59:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 05:59:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 05:59:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 05:59:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 05:59:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 05:59:51 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 05:59:55 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:00:08 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 06:07:15 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 06:07:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 06:07:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 06:07:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 06:07:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 06:07:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 06:07:16 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 06:20:28 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 06:22:49 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 06:22:49 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 06:22:49 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 06:22:49 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 06:22:49 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 06:22:49 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 06:22:55 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:23:17 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:23:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 589
ERROR - 2016-12-14 06:23:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 603
ERROR - 2016-12-14 06:23:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 612
ERROR - 2016-12-14 06:23:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 642
ERROR - 2016-12-14 06:23:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 656
ERROR - 2016-12-14 06:23:28 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 665
ERROR - 2016-12-14 06:28:21 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:28:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 495
ERROR - 2016-12-14 06:28:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 509
ERROR - 2016-12-14 06:28:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 518
ERROR - 2016-12-14 06:28:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 548
ERROR - 2016-12-14 06:28:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 562
ERROR - 2016-12-14 06:28:29 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 571
ERROR - 2016-12-14 06:28:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 495
ERROR - 2016-12-14 06:28:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 509
ERROR - 2016-12-14 06:28:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 518
ERROR - 2016-12-14 06:28:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 548
ERROR - 2016-12-14 06:28:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 562
ERROR - 2016-12-14 06:28:31 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 571
ERROR - 2016-12-14 06:28:38 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:29:34 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:29:50 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 06:30:33 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:30:44 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-14 06:35:54 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 06:39:17 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/views/userfolders.php 47
ERROR - 2016-12-14 06:40:06 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/views/userfolders.php 47
ERROR - 2016-12-14 06:40:24 --> Severity: Notice --> Trying to get property of non-object /home/power/public_html/B202/application/views/userfolders.php 47
ERROR - 2016-12-14 06:43:41 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-14 13:05:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/application/controllers/Companyview.php:15) /home/power/public_html/B202/system/core/Common.php 573
ERROR - 2016-12-14 13:05:02 --> Severity: Error --> Call to a member function num_rows() on boolean /home/power/public_html/B202/application/controllers/Companyview.php 15
ERROR - 2016-12-14 14:05:44 --> 404 Page Not Found: Css/bootstrap.min.css.map
