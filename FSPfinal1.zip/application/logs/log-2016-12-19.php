<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-19 00:58:06 --> 404 Page Not Found: Ib/html5shiv
ERROR - 2016-12-19 00:58:07 --> 404 Page Not Found: Lib/respond
ERROR - 2016-12-19 05:34:11 --> 404 Page Not Found: B202fspzip/index
ERROR - 2016-12-19 12:27:43 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-19 12:30:52 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-19 12:31:56 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-19 13:34:37 --> Severity: Warning --> rmdir(/home/power/public_html/B202/folders/hello): Directory not empty /home/power/public_html/B202/application/controllers/Userfolder.php 360
ERROR - 2016-12-19 13:34:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/system/core/Exceptions.php:271) /home/power/public_html/B202/system/helpers/url_helper.php 564
ERROR - 2016-12-19 13:35:27 --> Severity: Warning --> rmdir(/home/power/public_html/B202/folders/new): Directory not empty /home/power/public_html/B202/application/controllers/Userfolder.php 360
ERROR - 2016-12-19 13:35:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/power/public_html/B202/system/core/Exceptions.php:271) /home/power/public_html/B202/system/helpers/url_helper.php 564
ERROR - 2016-12-19 14:58:10 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/power/public_html/B202/application/views/companyabout.php 4
