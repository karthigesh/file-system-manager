<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-09 10:13:58 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 10:15:22 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 10:17:25 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 10:19:56 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 10:35:56 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 10:38:07 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 10:39:29 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 10:40:57 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 10:41:20 --> 404 Page Not Found: Company/index
ERROR - 2016-12-09 10:58:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 591
ERROR - 2016-12-09 10:58:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 601
ERROR - 2016-12-09 10:58:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 607
ERROR - 2016-12-09 10:58:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 636
ERROR - 2016-12-09 10:58:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 646
ERROR - 2016-12-09 10:58:06 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 652
ERROR - 2016-12-09 10:58:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 591
ERROR - 2016-12-09 10:58:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 601
ERROR - 2016-12-09 10:58:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 607
ERROR - 2016-12-09 10:58:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 636
ERROR - 2016-12-09 10:58:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 646
ERROR - 2016-12-09 10:58:11 --> Severity: Notice --> Undefined variable: photomode /home/power/public_html/B202/application/views/folders.php 652
ERROR - 2016-12-09 11:42:17 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-09 11:42:33 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-09 11:42:47 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 11:42:54 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 11:42:58 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-09 11:42:58 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 11:43:13 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 11:43:37 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 11:43:59 --> Severity: Notice --> Undefined variable: site_title /home/power/public_html/B202/application/views/template/adminuser/header.php 10
ERROR - 2016-12-09 11:51:44 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 11:52:09 --> 404 Page Not Found: Css/bootstrap.min.css.map
ERROR - 2016-12-09 12:17:39 --> 404 Page Not Found: Css/bootstrap.min.css.map
