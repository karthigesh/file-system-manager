</div><!-- mainpanel -->
</section>
<?php if(isset($files)){
	echo include_files($files, 'footer');
}
?>
</body>
</html>
