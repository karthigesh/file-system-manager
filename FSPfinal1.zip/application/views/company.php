<div id="company">
	<?php echo $company->splashscreen;?>
</div>
